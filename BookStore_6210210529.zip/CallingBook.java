import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileReader;
import java.util.Arrays;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.*;



public class CallingBook{
    public static void main (String[] args) throws FileNotFoundException, IOException{
        Firstpage b2 = new Firstpage(); 
        b2.firstpage();
        
    }
}



